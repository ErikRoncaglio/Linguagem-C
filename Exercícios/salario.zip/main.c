/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
  #include <stdio.h>
    
    int main(){
    float sal, re;
    int pe;
    
    scanf("%f",&sal);
    if((sal>0) && (sal<=400)){
    re=(sal/100)*15;
    sal=re+sal;
    pe=15;
    }
        else if((sal>400) && (sal<=800)){
        re=(sal/100)*12;
        sal=re+sal;
        pe=12;
        }
            else if((sal>800) && (sal<=1200)){
            re=(sal/100)*10;
            sal=re+sal;
            pe=10;
            }
                else if((sal>1200) && (sal<=2000)){
                re=(sal/100)*7;
                sal=re+sal;
                pe=7;
                }
                    else if(sal>2000){
                    re=(sal/100)*4;
                    sal=re+sal;
                    pe=4;
                    }
       printf("Novo salario: %.2f\nReajuste ganho: %.2f\nEm percentual: %d %%\n",sal,re,pe);
    }
