/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
 
int main() {
    float k, m;
    printf("informe a velocidade em km/h:");
    scanf("%f",&k);
    m=k/3.6;
    printf("A velocidade é %f m/s",m);
}
