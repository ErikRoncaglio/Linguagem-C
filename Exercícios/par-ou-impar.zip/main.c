/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main(){
    int N,X,a;
    
    scanf ("%d", &N);
    for(a=1;a<=N;a++){
        scanf ("%d",&X);
        if(X==0)
            printf("NULL\n");
        else if(X<=0 && X%2==0)
            printf ("EVEN NEGATIVE\n");
        else if(X<=0 && X%2==-1)
            printf ("ODD NEGATIVE\n");
        else if(X>=0 && X%2==0)
            printf ("EVEN POSITIVE\n");
        else if(X>=0 && X%2==1)
            printf ("ODD POSITIVE\n");
    }
}