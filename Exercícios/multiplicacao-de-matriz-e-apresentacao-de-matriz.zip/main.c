/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main(){
float a[3][3],R[3][3];
int n, j, i;
printf("    Informe o número inteiro que queres multiplicar:");
scanf("%d",&n);
for (i=0;i<3;i++){
    for (j=0;j<3;j++){
        printf("    Informe os valores da matriz:");
        scanf("%f",&a[i][j]);
        R[i][j]=a[i][j]*n;
    }
}
printf("\n\n    A multiplicação da matriz é:\n");
for (i=0;i<3;i++){
  printf("\n    ");  
for (j=0;j<3;j++){
printf(" %.2f",R[i][j]);
}
}
    return 0;
}
