/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main(){
int i, n=3, j, a[4][4], b[4][4];
printf("informe os valores da primeira matriz:");
for (i=0;i<4;i++){
for (j=0;j<4;j++){
    scanf("%d",&a[i][j]);
}
}
printf("informe os valores da segunda matriz:");
for (i=0;i<4;i++){
for (j=0;j<4;j++){
    scanf("%d",&b[i][j]);
}
}
for (i=0;i<4;i++){
for (j=0;j<4;j++){
a[i][j]+=b[i][j];
}
}
printf("A soma das matrizes é:");
for (i=0;i<4;i++){
  printf("\n");  
for (j=0;j<4;j++){
printf(" %d",a[i][j]);
}
}
    return 0;
}

