/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
int main(){
    int n, a, b, c, d, e, f, g;
    scanf("%d", &n);
    a=n/100;
    b=(n-a*100)/50;
    c=(n-(a*100+b*50))/20;
    d=(n-(a*100+b*50+c*20))/10;
    e=(n-(a*100+b*50+c*20+d*10))/5;
    f=(n-(a*100+b*50+c*20+d*10+e*5))/2;
    g=(n-(a*100+b*50+c*20+d*10+e*5+f*2))/1;
    printf("%d\n%d nota(s) de R$ 100,00\n%d nota(s) de R$ 50,00\n%d nota(s) de R$ 20,00\n%d nota(s) de R$ 10,00\n%d nota(s) de R$ 5,00\n%d nota(s) de R$ 2,00\n%d nota(s) de R$ 1,00\n", n, a, b, c, d, e, f, g);
}
