/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>

int main() {
float n;

scanf("%f",&n);
if ((n>100) || (n<0)){
    printf("Fora de intervalo");
}
if((n>=0) && (n<=25)){
    printf("Intervalo [0,25]");
}
if((n>25) && (n<=50)){
    printf("Intervalo (25,50]");
}
if((n>50) && (n<=75)){
    printf("Intervalo (50,75]");
}
if((n>75) && (n<=100)){
    printf("Intervalo (75,100]");
}
}